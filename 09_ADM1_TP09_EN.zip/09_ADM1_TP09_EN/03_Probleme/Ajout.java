package com.rappel;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class Ajout extends AppCompatActivity {
    private EditText edNom;
    private EditText edPrenom;
    private EditText edTelephone;
    private Button btnAjouter;
    private Button btnAnnuler;


    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ajout);
    }
    private void init(){
        edNom=findViewById(R.id.edNom);
        edPrenom=findViewById(R.id.edPrenom);
        edTelephone=findViewById(R.id.edTelephone);
        btnAjouter=findViewById(R.id.btnAjouter);
        btnAnnuler=findViewById(R.id.btnAnnuler);

    }
}