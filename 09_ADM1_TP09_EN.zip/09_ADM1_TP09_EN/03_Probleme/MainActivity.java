package com.rappel;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {
    private EditText edTitre;
    private EditText edLieu;
    private EditText edDu;
    private EditText edAu;
    private Button btnAjout;
    private Button btnRappelerTout;
    private ListView lstParticipant;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }
    private void init(){
        edTitre=findViewById(R.id.edTitre);
        edLieu=findViewById(R.id.edLieu);
        edDu=findViewById(R.id.edDu);
        edAu=findViewById(R.id.edAu);
        btnAjout=findViewById(R.id.btnAjout);
        btnRappelerTout=findViewById(R.id.btnRappelerTout);
        lstParticipant=findViewById(R.id.lstParticipant);
    }
}