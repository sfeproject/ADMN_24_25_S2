package com.rappel;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class Rappel extends AppCompatActivity {
    private EditText edSeminaire;
    private EditText edParticipant;
    private Button btnRappeler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rappel);
    }
    private void init(){
        edSeminaire=findViewById(R.id.edSeminaire);
        edParticipant=findViewById(R.id.edParticipant);
        btnRappeler=findViewById(R.id.btnRappeler);


    }
}