package com.focus;

import com.formulairefocus.R;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity {
	private EditText edNom;
	private EditText edPrenom;
	private EditText edAdresse;
	private Button btnAjouter;
	private int couleurInitiale;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		init();
	}

	public void init() {
		edNom = (EditText) findViewById(R.id.edNom);
		edPrenom = (EditText) findViewById(R.id.edPrenom);
		edAdresse = (EditText) findViewById(R.id.edAdresse);
		btnAjouter = (Button) findViewById(R.id.btnAjouter);

	}

}
