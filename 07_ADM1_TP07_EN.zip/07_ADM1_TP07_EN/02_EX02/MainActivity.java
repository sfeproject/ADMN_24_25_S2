package com.sms;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity {
  private EditText edNumero;
  private EditText edCorps;
  private Button btnEnvoyer;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    initGraphique();
  }
  private void initGraphique() {
	

    edNumero= findViewById(R.id.edNumero);
    edCorps= findViewById(R.id.edCorps);
    btnEnvoyer= findViewById(R.id.btnEnvoyer);
    ajouterEcouteur();
  }
  private void ajouterEcouteur() {
  
    
  }
 
  
}

