package com.appel;



import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {


    private EditText edNumero;
    private Button btnAppeler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initGraphique();
    }

    private void initGraphique() {
        edNumero =  findViewById(R.id.edNumero);
        btnAppeler = findViewById(R.id.btnAppeler);
        ajouterEcouteur();
    }

    private void ajouterEcouteur() {
       
    }

    
}
