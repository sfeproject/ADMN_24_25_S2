package projet.com.test;

public class TestCovid19 {

    private int type;    // 0 : Test de référence             1 : Test rapide
    private String cin;
    private int age;
    private boolean imF; // false: immunité normale           true : immunité faible
    private boolean maC; // false: pas de maladie chronique   true : présence d'une maladie chronique
    private String res;  // "Covid19-" ou "Covid19+"

    public TestCovid19(int type, String cin, int age, boolean imF, boolean maC, String res) {
        this.type = type;
        this.cin = cin;
        this.age = age;
        this.imF = imF;
        this.maC = maC;
        this.res = res;
    }

    public int getType() {
        return type;
    }

    public String getCin() {
        return cin;
    }

    public int getAge() {
        return age;
    }

    public boolean isImF() {
        return imF;
    }

    public boolean isMaC() {
        return maC;
    }

    public String getRes() {
        return res;
    }

    public String getInterpretation() {
        if (res.equalsIgnoreCase("Covid19+")) {
            if (maC || imF)
                return "Très Grave";
            return "Grave";
        }
        return "Sain";
    }

    @Override
    public String toString() {
        String strType = "";
        if (type == 0)      strType = "Référence";
        else      strType = "Rapide";
        return strType + ": " +  cin + "("+age+")"+
                " -> "+ getRes();
    }

}
