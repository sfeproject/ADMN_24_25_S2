package com.recup_resultat;

public class MainActivity extends Activity {
  private Button btnNouveau;
  private ListView lstPersonne;
  public static final int NOUVEAU=1;
  private ArrayAdapter<Personne> adpPersonne; 
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    init();
  }
  private void init() {
    btnNouveau= (Button) findViewById(R.id.btnNouveau);
    lstPersonne= (ListView) findViewById(R.id.lstPersonne);
    adpPersonne= new ArrayAdapter<Personne>(this, android.R.layout.simple_list_item_1);
    lstPersonne.setAdapter(adpPersonne);
    ajouterEcouteur();
  }
  private void ajouterEcouteur() {
      
  }   
}
