package com.tartil.passageparam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.SeekBar;

public class MainActivity extends AppCompatActivity {
    private EditText edNomPre;
    private CheckBox chMotorise;
    private SeekBar seekAge;
    private Button btnSol1;
    private Button btnSol2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();

    }

    private void init() {
        edNomPre=findViewById(R.id.edNomPre);
        chMotorise=findViewById(R.id.chMotorise);
        seekAge=findViewById(R.id.seekAge);
        btnSol1=findViewById(R.id.btnSol1);
        btnSol2=findViewById(R.id.btnSol2);
        ajouterEcouteurs();
    }

    private void ajouterEcouteurs() {
       
    }

    
}